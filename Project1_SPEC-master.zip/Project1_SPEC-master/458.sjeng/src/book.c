/*
    Sjeng - a chess variants playing program
    Copyright (C) 2000-2003 Gian-Carlo Pascutto

    File: book.c                                             
    Purpose: book initialization, selection of book moves, etc...

*/

#include "sjeng.h"
#include "protos.h"
#include "extvars.h"

/* Uninteresting for SPEC */

int init_book (void) {

   return TRUE;

}

move_s choose_book_move (void) {

   return dummy;

}

