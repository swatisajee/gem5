#!/bin/sh

cd data/
../src/benchmark inp.in
